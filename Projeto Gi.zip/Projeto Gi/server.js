const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const bodyParser = require('body-parser'); // Para processar dados do formulário
const multer = require('multer');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuração do multer para upload de imagens
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/images/'); // Pasta para armazenar as imagens
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // Nome único para cada arquivo
    }
});
const upload = multer({ storage: storage });
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(session({
    secret: 'your-session-secret',
    resave: false,
    saveUninitialized: true
}));

// Conectar ao banco de dados MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'productdb'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Conectado ao banco de dados MySQL.');
});

// Rota para exibir os produtos na página inicial
app.get('/', (req, res) => {
    // Consulta para obter produtos
    const produtosQuery = 'SELECT * FROM products';
    // Consulta para obter imagens do carrossel
    const carrosselQuery = 'SELECT * FROM carrossel'; // Ajuste o nome da tabela conforme sua configuração

    // Executa as consultas em paralelo
    db.query(produtosQuery, (err, produtos) => {
        if (err) throw err;

        db.query(carrosselQuery, (err, carrosselImagens) => {
            if (err) throw err;

            // Renderiza a página com produtos e imagens do carrossel
            res.render('index', { products: produtos, imagensCarrossel: carrosselImagens });
        });
    });
});

// Rota para exibir o formulário de adição de produto
app.get('/add-product', ensureAuthenticated, (req, res) => {
    res.render('add-product');
});

// Rota para adicionar o produto ao banco de dados
app.post('/add-product', upload.single('imagem'), (req, res) => {
    const { nome, preco, descricao } = req.body;
    const imagem = req.file ? req.file.filename : null; // Nome da imagem enviada, se houver

    if (!imagem) {
        return res.status(400).send('Erro ao fazer upload da imagem.');
    }

    const sql = 'INSERT INTO products (nome, preco, descricao, imagem) VALUES (?, ?, ?, ?)';
    db.query(sql, [nome, preco, descricao, imagem], (err, result) => {
        if (err) throw err;
        res.redirect('/admin'); // Redireciona para a página principal após adicionar o produto
    });
});

// Iniciar o servidor na porta definida
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});

// Rota para exibir o formulário de edição de produto
app.get('/edit-product/:id', ensureAuthenticated, (req, res) => {
    const productId = req.params.id;
    const query = 'SELECT * FROM products WHERE id = ?';
    db.query(query, [productId], (err, results) => {
        if (err) throw err;
        res.render('edit-product', { product: results[0] });
    });
});

// Rota para atualizar o produto
app.post('/admin/edit/:id', upload.single('imagem'), (req, res) => {
    const id = req.params.id;
    const { nome, preco, descricao } = req.body;
    const imagem = req.file ? req.file.filename : null;

    const query = 'UPDATE products SET nome = ?, preco = ?, descricao = ?, imagem = ? WHERE id = ?';
    db.query(query, [nome, preco, descricao, imagem, id], (err, result) => {
        if (err) throw err;
        res.redirect('/admin');
    });
});

// Rota para excluir o produto
app.get('/delete-product/:id', ensureAuthenticated, (req, res) => {
    const productId = req.params.id;
    const query = 'DELETE FROM products WHERE id = ?';
    db.query(query, [productId], (err, result) => {
        if (err) throw err;
        res.redirect('/admin');
    });
});


app.get('/login', (req, res) => {
    res.render('login');
});

// Processar o login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const query = 'SELECT * FROM admins WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
            req.session.user = results[0]; // Armazena o usuário na sessão
            res.redirect('/admin'); // Redireciona para o painel administrativo
        } else {
            res.status(401).send('Usuário ou senha inválidos.');
        }
    });
});

// Página administrativa
app.get('/admin', ensureAuthenticated, (req, res) => {
    // Buscar produtos
    const queryProducts = 'SELECT * FROM products';
    // Buscar imagens do carrossel
    const queryCarousel = 'SELECT * FROM carrossel';

    db.query(queryProducts, (err, products) => {
        if (err) throw err;

        db.query(queryCarousel, (err, carouselImages) => {
            if (err) throw err;
            res.render('admin', { products: products, carrossel: carouselImages });
        });
    });
});



// Middleware para verificar autenticação
function ensureAuthenticated(req, res, next) {
    if (req.session.user) {
        return next(); // Usuário autenticado, continua para a próxima função
    }
    res.redirect('/login'); // Usuário não autenticado, redireciona para a página de login
}

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).send('Erro ao encerrar sessão.');
        }
        res.redirect('/login'); // Redireciona para a página de login após logout
    });
});

const upload2 = multer({ dest: 'uploads/' });

app.get('/admin/add-carousel', ensureAuthenticated, (req, res) => {
    res.render('add-carrossel'); // Página com o formulário para adicionar uma nova imagem ao carrossel
});

app.post('/admin/carrossel/add', upload.single('imagem'), (req, res) => {
    const { legenda } = req.body;
    const imagem = req.file ? req.file.filename : null;

    if (!imagem) {
        return res.status(400).send('Erro ao fazer upload da imagem.');
    }

    const sql = 'INSERT INTO carrossel (imagem, legenda) VALUES (?, ?)';
    db.query(sql, [imagem, legenda], (err, result) => {
        if (err) throw err;
        res.redirect('/admin');
    });
});

app.get('/admin/edit-carousel/:id', ensureAuthenticated, (req, res) => {
    const id = req.params.id;
    const query = 'SELECT * FROM carrossel WHERE id = ?';

    db.query(query, [id], (err, results) => {
        if (err) throw err;
        res.render('edit-carrossel', { imagem: results[0] });
    });
});

app.post('/admin/edit-carousel/:id', upload.single('imagem'), (req, res) => {
    const id = req.params.id;
    const { legenda } = req.body;
    const imagem = req.file ? req.file.filename : null;

    let query = 'UPDATE carrossel SET legenda = ?';
    let values = [legenda];

    if (imagem) {
        query += ', imagem = ?';
        values.push(imagem);
    }

    query += ' WHERE id = ?';
    values.push(id);

    db.query(query, values, (err, result) => {
        if (err) throw err;
        res.redirect('/admin');
    });
});


app.get('/admin/delete-carousel/:id', ensureAuthenticated, (req, res) => {
    const id = req.params.id;
    const query = 'DELETE FROM carrossel WHERE id = ?';

    db.query(query, [id], (err, result) => {
        if (err) throw err;
        res.redirect('/admin');
    });
});
